#!/bin/bash
for i in $(seq -f "%02g" 0 98)
do
  if [ $i -le 9 ]; then
     a=`cat $i.txt | wc -l`
  else
     a=`cat $i.txt | wc -l`
   fi
   if [ $a -le 9 ]; then
      cp $i.txt /home/kerem/HW3/0$a   # please change to your current directory
   else
      cp $i.txt /home/kerem/HW3/$a    # please change to your current directory
   fi
done
