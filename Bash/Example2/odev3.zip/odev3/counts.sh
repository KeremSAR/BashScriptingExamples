#!/bin/bash
for i in $(seq -f "%02g" 0 98)
do
  cat $i.txt | wc -l
done
